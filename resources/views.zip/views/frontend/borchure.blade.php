@extends('frontend.layout.master')
@section('content')

                        <!-- main content section -->
                        <div class="">
                            <div class="row">
                                <div class="col-sm-12 col-md-12 col-lg-12">
                                    <div class="">
                                        <div class="head-reg my-5 text-center box-reg">
                                            <p>Brochure</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-12 col-lg-12">
                                    <div class="box-reg">
                                        <embed src="{{asset('')}}frontend/documents/Brochure of the Conference-1.pdf" width="100%" height="1370px" />
                                    </div> 
                                </div>
                            </div>
                        </div>
                        
                        <!-- footer -->
@endsection