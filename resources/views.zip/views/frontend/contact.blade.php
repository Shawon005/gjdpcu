@extends('frontend.layout.master')
@section('content')

                        <!-- main content section -->
                        <div class="">
                            <div class="row">
                                <div class="col-sm-12 col-md-12 col-lg-12">
                                    <div class="">
                                        <div class="head-reg my-5 text-center box-reg">
                                            <p>Contact</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-12 col-lg-12">
                                    <div class="box-reg">
                                        
                                        <p>For further information and submission, please contact us at +880 1712102014 (Professor Dr. Iqbal Shahin Khan), +880 1711284707 (Masum Ahmed).</p>
                                    </div> 
                                </div>
                            </div>
                        </div>
                        
                        <!-- footer -->
@endsection