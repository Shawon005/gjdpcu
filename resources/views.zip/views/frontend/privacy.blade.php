@extends('frontend.layout.master')
@section('content')

                        <!-- main content section -->
                        <div class="" style="min-height: 500px">
                            <div class="row">
                                <div class="col-sm-12 col-md-12 col-lg-12">
                                    <div class="">
                                        <div class="head-reg my-5 text-center box-reg">
                                            <p>PRIVACY POLICY</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-12 col-lg-12">
                                    <div class="row my-2">
                                        <div class="col-sm-12 col-md-12 col-lg-12 mt-2">
                                            <div class="box-reg">
                                                <h4 align="center"><b>Last updated on July 15, 2023</b></h4>
                                                <ul>
                                                    <li> This privacy policy (" Privacy Policy") applies to your use of the CUPHILOSOPHY website located at https://cuphilosophy.com (" CUPHILOSOPHY" or " Website"), The terms " we", " our" and " us" refer to CUPHILOSOPHY and the terms " you", " your" and " User" refer to you, as a user of CUPHILOSOPHY .  </li>
                                                    <li> The term " Personal Information" means information that you provide to us which personally identifies you to be contacted or identified, such as your name, phone number, email address, and any other data.</li>
                                                </ul>
                                            </div>
                                        </div>
                                        
                                    </div> 
                                </div>
                            </div>
                        </div>
                        

                        <!-- footer -->
 @endsection