@extends('frontend.layout.master')
@section('content')

                        <!-- main content section -->
                        <div class="">
                            <div class="row">
                                <div class="col-sm-12 col-md-12 col-lg-12">
                                    <div class="">
                                        <div class="head-reg my-5 text-center box-reg">
                                            <p>Registration Fee</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-12 col-lg-12">
                                    <div class="box-reg">
                                        <h4></h4>
                                         <ul>
                                            <li>Foreign Researchers: USD 80</li>
                                            <li>Local Researchers: BDT 3000</li>
                                            <li>Bank Information:</li>
                                            
                                         </ul>
                                         <p>Name of Bank: A B Bank (Anderkilla Branch),<br>Account’s Name:   Masum Ahmed <br>Account Number: 4125 109903 300 <br>Routing Number: 020150493,   SWIFT Code: ABBLBDDH<br>Note: Please note that due to financial limitations, only local hospitality, including accommodation, food, and local transport, will be provided, and participants are responsible for arranging their own international or domestic transportation.</p>
                                    </div> 
                                </div>
                            </div>
                        </div>
                        
                        <!-- footer -->
@endsection