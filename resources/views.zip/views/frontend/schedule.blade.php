@extends('frontend.layout.master')
@section('content')

    <!-- main content section -->
    <div class="" style="min-height: 500px">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="">
                    <div class="head-reg my-5 text-center box-reg">
                        <p>PROGRAME SCHEDULE</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="row my-2">
                    <div class="col-sm-12 col-md-12 col-lg-12 mt-2">
                        <div class="head-reg box-reg">
                            <h3 class="text-center">Schedule will be updated soon...</h3>
                        </div>
                    </div>
                    
                </div> 
            </div>
        </div>
    </div>
    

    <!-- footer -->
 @endsection